var searchData=
[
  ['adc_5fclock_0',['ADC_CLOCK',['../measuring_8c.html#a1827eb5abf90948b5eaf230be00170fd',1,'measuring.c']]],
  ['adc_5fclocks_5fps_1',['ADC_CLOCKS_PS',['../measuring_8c.html#ad376b870a0bfe67bc29f21d6b66ff086',1,'measuring.c']]],
  ['adc_5fdac_5fres_2',['ADC_DAC_RES',['../measuring_8c.html#a1a99cc3586f8ed1522076e58e22ca0f7',1,'measuring.c']]],
  ['adc_5ffs_3',['ADC_FS',['../measuring_8c.html#aa8ccd2dce306c0d219eeabd92b30fcc0',1,'measuring.c']]],
  ['adc_5fnums_4',['ADC_NUMS',['../measuring_8c.html#a0a4c3d17b626e4d7b31b780e85dde7cf',1,'measuring.c']]]
];
