var searchData=
[
  ['adc_5fsample_5fcount_0',['ADC_sample_count',['../measuring_8c.html#a70e7c139b5911548b5eacdd74e471d5b',1,'measuring.c']]],
  ['adc_5fsamples_1',['ADC_samples',['../measuring_8c.html#ab7f88c24d5816d6d48d932fdb53caaf2',1,'measuring.c']]]
];
