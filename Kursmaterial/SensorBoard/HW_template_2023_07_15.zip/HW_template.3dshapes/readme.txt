Put 2 files with same names and the extension .step and .wrl
https://forum.kicad.info/t/what-is-the-difference-between-step-and-wrl-3d-models/17346
