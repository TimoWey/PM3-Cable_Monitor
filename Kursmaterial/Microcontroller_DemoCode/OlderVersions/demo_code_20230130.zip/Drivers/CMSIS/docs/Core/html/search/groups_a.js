var searchData=
[
  ['version_20control_20per_20core_20_28depricated_29',['Version Control per Core (Depricated)',['../group__version__control__depricated__gr.html',1,'']]],
  ['version_20control',['Version Control',['../group__version__control__gr.html',1,'']]]
];
