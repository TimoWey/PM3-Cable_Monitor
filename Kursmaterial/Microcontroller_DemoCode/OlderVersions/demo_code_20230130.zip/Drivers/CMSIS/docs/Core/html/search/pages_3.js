var searchData=
[
  ['misra_2dc_20deviations',['MISRA-C Deviations',['../coreMISRA_Exceptions_pg.html',1,'']]]
];
