var unionCONTROL__Type =
[
    [ "_reserved0", "unionCONTROL__Type.html#af8c314273a1e4970a5671bd7f8184f50", null ],
    [ "b", "unionCONTROL__Type.html#adc6a38ab2980d0e9577b5a871da14eb9", null ],
    [ "FPCA", "unionCONTROL__Type.html#ac62cfff08e6f055e0101785bad7094cd", null ],
    [ "nPRIV", "unionCONTROL__Type.html#a35c1732cf153b7b5c4bd321cf1de9605", null ],
    [ "SPSEL", "unionCONTROL__Type.html#a8cc085fea1c50a8bd9adea63931ee8e2", null ],
    [ "w", "unionCONTROL__Type.html#a6b642cca3d96da660b1198c133ca2a1f", null ]
];