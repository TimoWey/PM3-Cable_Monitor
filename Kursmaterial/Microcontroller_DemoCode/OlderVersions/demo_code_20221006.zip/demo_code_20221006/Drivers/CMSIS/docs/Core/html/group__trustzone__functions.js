var group__trustzone__functions =
[
    [ "Core Register Access Functions", "group__coreregister__trustzone__functions.html", "group__coreregister__trustzone__functions" ],
    [ "NVIC Functions", "group__nvic__trustzone__functions.html", "group__nvic__trustzone__functions" ],
    [ "SysTick Functions", "group__systick__trustzone__functions.html", "group__systick__trustzone__functions" ],
    [ "SAU Functions", "group__sau__trustzone__functions.html", "group__sau__trustzone__functions" ],
    [ "RTOS Context Management", "group__context__trustzone__functions.html", "group__context__trustzone__functions" ]
];