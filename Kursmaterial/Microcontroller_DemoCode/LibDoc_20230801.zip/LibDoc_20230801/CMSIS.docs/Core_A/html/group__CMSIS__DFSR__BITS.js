var group__CMSIS__DFSR__BITS =
[
    [ "DFSR_CM_Msk", "group__CMSIS__DFSR__BITS.html#ga91cf285dc43beda62ae72f043e83238c", null ],
    [ "DFSR_CM_Pos", "group__CMSIS__DFSR__BITS.html#gac1c7d8f30e77bd1fe395d6e9a5a63a3e", null ],
    [ "DFSR_Domain_Msk", "group__CMSIS__DFSR__BITS.html#ga59949776e069a5af7231ef63156f17cf", null ],
    [ "DFSR_Domain_Pos", "group__CMSIS__DFSR__BITS.html#gac5a7afc43963dbc429792fb5a1569e15", null ],
    [ "DFSR_Ext_Msk", "group__CMSIS__DFSR__BITS.html#gad3a97b4eb87f45df8ae539e59592f21b", null ],
    [ "DFSR_Ext_Pos", "group__CMSIS__DFSR__BITS.html#ga8cc8dcb1b3a971a13b0575bf9083acf5", null ],
    [ "DFSR_FS0_Msk", "group__CMSIS__DFSR__BITS.html#ga23b688e81c0378b5cd75acb53896bb5e", null ],
    [ "DFSR_FS0_Pos", "group__CMSIS__DFSR__BITS.html#gae5d9bc62e71693bd9dc2a84bb4c82082", null ],
    [ "DFSR_FS1_Msk", "group__CMSIS__DFSR__BITS.html#ga6540a3ca5b2dcf8f81bb37fbdbe9d746", null ],
    [ "DFSR_FS1_Pos", "group__CMSIS__DFSR__BITS.html#ga3faee10970931cadf7ff16069ce65a1a", null ],
    [ "DFSR_LPAE_Msk", "group__CMSIS__DFSR__BITS.html#ga104bfa1e333340616fdbdc804948276f", null ],
    [ "DFSR_LPAE_Pos", "group__CMSIS__DFSR__BITS.html#ga10f7b48c4f128c9be07c377bb60cfa7a", null ],
    [ "DFSR_STATUS_Msk", "group__CMSIS__DFSR__BITS.html#ga7541052737038d737fd9fe00b9815140", null ],
    [ "DFSR_STATUS_Pos", "group__CMSIS__DFSR__BITS.html#gacb6fae1908b12c4900e2cdcc320c6c11", null ],
    [ "DFSR_WnR_Msk", "group__CMSIS__DFSR__BITS.html#gabfbf482895e7620fe6727b54378c0f2a", null ],
    [ "DFSR_WnR_Pos", "group__CMSIS__DFSR__BITS.html#ga410420633e9ba47cdd1ae2d3df146866", null ]
];