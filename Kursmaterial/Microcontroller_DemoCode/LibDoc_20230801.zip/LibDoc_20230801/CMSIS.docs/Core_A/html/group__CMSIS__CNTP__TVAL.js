var group__CMSIS__CNTP__TVAL =
[
    [ "__get_CNTP_TVAL", "group__CMSIS__CNTP__TVAL.html#ga94321d86e23339a3de6e48ae1b4e006d", null ],
    [ "__set_CNTP_TVAL", "group__CMSIS__CNTP__TVAL.html#ga5cd55833483552e023c9b2ead0c97a02", null ]
];