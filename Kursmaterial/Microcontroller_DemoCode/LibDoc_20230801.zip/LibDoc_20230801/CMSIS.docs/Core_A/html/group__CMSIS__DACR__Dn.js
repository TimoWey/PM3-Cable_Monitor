var group__CMSIS__DACR__Dn =
[
    [ "DACR_Dn_CLIENT", "group__CMSIS__DACR__Dn.html#gac76e6128758cd64a9fa92487ec49441b", null ],
    [ "DACR_Dn_MANAGER", "group__CMSIS__DACR__Dn.html#gabbf27724d67055138bf7abdb651e9732", null ],
    [ "DACR_Dn_NOACCESS", "group__CMSIS__DACR__Dn.html#ga281ebf97decb4ef4f7b1e5c4285c45ab", null ]
];