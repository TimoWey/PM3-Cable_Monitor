var group__CMSIS__CPACR__BITS =
[
    [ "CPACR_ASEDIS_Msk", "group__CMSIS__CPACR__BITS.html#ga46d28804bfa370b0dd4ac520a7a67609", null ],
    [ "CPACR_ASEDIS_Pos", "group__CMSIS__CPACR__BITS.html#ga3acd342ab1e88bd4ad73f5670e7af163", null ],
    [ "CPACR_CP_Msk_", "group__CMSIS__CPACR__BITS.html#ga7c87723442baa681a80de8f644eda1a2", null ],
    [ "CPACR_CP_Pos_", "group__CMSIS__CPACR__BITS.html#ga77dc035e6d16dee8f5cf53b36b86cfaf", null ],
    [ "CPACR_D32DIS_Msk", "group__CMSIS__CPACR__BITS.html#ga96266eb6bf35c3c3f22718bd06b12d79", null ],
    [ "CPACR_D32DIS_Pos", "group__CMSIS__CPACR__BITS.html#ga6df0c4e805105285e63b0f0e992bd416", null ],
    [ "CPACR_TRCDIS_Msk", "group__CMSIS__CPACR__BITS.html#gab5d6ec83339e755bd3e7eacb914edf37", null ],
    [ "CPACR_TRCDIS_Pos", "group__CMSIS__CPACR__BITS.html#ga6866c97020fdba42f7c287433c58d77c", null ]
];